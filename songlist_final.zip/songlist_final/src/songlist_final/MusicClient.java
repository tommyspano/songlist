package songlist_final;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class MusicClient {
    // Costante per la directory in cui salvare i file scaricati
    private static final String DOWNLOAD_DIR = "downloaded_songs";

    public static void main(String[] args) {
        // Crea la cartella di download se non esiste
        File downloadFolder = new File(DOWNLOAD_DIR);
        if (!downloadFolder.exists()) {
            downloadFolder.mkdir();
        }

        // Prova a connettersi al server sulla porta 12345
        try (Socket socket = new Socket("127.0.0.1", 12345);
             DataInputStream input = new DataInputStream(socket.getInputStream()); // Per ricevere dati dal server
             DataOutputStream output = new DataOutputStream(socket.getOutputStream()); // Per inviare dati al server
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Connesso al server!");

            // Loop per interagire con il server
            while (true) {
                System.out.print("Inserisci un comando (LIST, PLAY <numero>, STOP, RESUME, EXIT): ");
                String command = scanner.nextLine(); // Legge il comando dall'utente

                output.writeUTF(command); // Invia il comando al server

                // Se il comando è EXIT, termina la connessione
                if (command.equalsIgnoreCase("EXIT")) {
                    System.out.println("Disconnessione...");
                    break;
                }

                // Riceve la risposta dal server
                String response = input.readUTF();

                // Se il server invia un file
                if (response.equals("SENDING_FILE")) {
                    String fileName = input.readUTF(); // Nome del file da scaricare
                    File downloadedFile = new File(downloadFolder, fileName); // Salva il file nella cartella di download
                    receiveFile(downloadedFile, input); // Scarica il file
                    System.out.println("Sto riproducendo " + fileName);

                // Se il trasferimento del file è completo
                } else if (response.equals("FILE_TRANSFER_COMPLETE")) {
                    System.out.println("Trasferimento file completato.");

                // Per ogni altra risposta dal server
                } else {
                    System.out.println(response);
                }
            }
        } catch (IOException e) {
            System.out.println("Errore nella comunicazione: " + e.getMessage());
        }
    }

    // Metodo per ricevere un file dal server
    private static void receiveFile(File file, DataInputStream input) throws IOException {
        // Legge la dimensione del file dal server
        long fileSize = input.readLong();

        try (FileOutputStream fileOutputStream = new FileOutputStream(file)) {
            byte[] buffer = new byte[4096]; // Buffer di 4KB per ricevere dati
            int bytesRead;
            long totalRead = 0; // Traccia i byte letti finora

            // Riceve il file in blocchi
            while (totalRead < fileSize && (bytesRead = input.read(buffer)) != -1) {
                fileOutputStream.write(buffer, 0, bytesRead); // Scrive i dati sul file
                totalRead += bytesRead; // Aggiorna il totale dei byte letti
            }
        }
    }
}