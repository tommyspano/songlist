package songlist_final;

import java.io.*;
import java.net.*;
import java.util.*;

public class MusicServer {
    // Costante per la directory in cui si trovano i file musicali del Server
    private static final String MUSIC_DIR = "songs";
    
    // Lista dei client connessi
    private static final List<ClientHandler> clients = new ArrayList<>();

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(12345)) { // Crea un server socket sulla porta 12345
            System.out.println("Server avviato e in ascolto sulla porta 12345...");
            
            // Loop infinito per rimanere sempre in ascolto e accettare connessioni dai client
            while (true) {
                Socket clientSocket = serverSocket.accept(); // Accetta una connessione
                System.out.println("Client connesso: " + clientSocket.getInetAddress());
                
                // Crea un handler per il client e lo aggiunge alla lista dei client connessi
                ClientHandler clientHandler = new ClientHandler(clientSocket);
                clients.add(clientHandler);
                
                // Avvia un thread separato per gestire il client
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            System.out.println("Errore del server: " + e.getMessage());
        }
    }

    // Classe interna per gestire ogni client connesso
    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;
        private boolean isPlaying = false; // Stato di riproduzione per il client

        // Costruttore: inizializza il socket del client
        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try (
                DataInputStream input = new DataInputStream(clientSocket.getInputStream()); // Input dal client
                DataOutputStream output = new DataOutputStream(clientSocket.getOutputStream()) // Output verso il client
            ) {
                // Carica la lista dei brani disponibili
                List<String> songs = loadSongs();

                // Loop infinito per rimanere sempre in ascolto e ricevere comandi dal client
                while (true) {
                    String command = input.readUTF(); // Legge il comando dal client
                    System.out.println("Comando ricevuto: " + command);

                    // Comando LIST: invia la lista delle canzoni disponibili
                    if (command.equals("LIST")) {
                        StringBuilder response = new StringBuilder();
                        for (int i = 0; i < songs.size(); i++) {
                            response.append((i + 1)).append(". ").append(songs.get(i)).append("\n");
                        }
                        output.writeUTF(response.toString());

                    // Comando PLAY <numero>: invia il file richiesto al client
                    } else if (command.startsWith("PLAY ")) {
                        int songIndex;
                        try {
                            // Estrae l'indice della canzone
                            songIndex = Integer.parseInt(command.substring(5)) - 1;
                            if (songIndex < 0 || songIndex >= songs.size()) {
                                output.writeUTF("ERROR: Numero di brano non valido");
                                continue;
                            }
                        } catch (NumberFormatException e) {
                            output.writeUTF("ERROR: Comando non valido");
                            continue;
                        }

                        String songName = songs.get(songIndex);
                        File songFile = new File(MUSIC_DIR, songName);

                        if (songFile.exists() && songFile.isFile()) {
                            output.writeUTF("SENDING_FILE");
                            output.writeUTF(songName); // Invia il nome del file
                            sendFile(songFile, output); // Invia il file al client
                            output.writeUTF("FILE_TRANSFER_COMPLETE");
                            isPlaying = true; // Aggiorna lo stato di riproduzione
                        } else {
                            output.writeUTF("ERROR: File non trovato");
                        }

                    // Comando STOP: interrompe la riproduzione
                    } else if (command.equals("STOP")) {
                        if (isPlaying) {
                            output.writeUTF("Riproduzione in pausa");
                            isPlaying = false;
                        } else {
                            output.writeUTF("Nessuna riproduzione in corso");
                        }

                    // Comando RESUME: riprende la riproduzione
                    } else if (command.equals("RESUME")) {
                        if (!isPlaying) {
                            output.writeUTF("Ripresa della riproduzione");
                            isPlaying = true;
                        } else {
                            output.writeUTF("La riproduzione è già in corso");
                        }

                    // Comando EXIT: chiude la connessione con il client
                    } else if (command.equals("EXIT")) {
                        System.out.println("Client disconnesso");
                        break;

                    // Comando non riconosciuto
                    } else {
                        output.writeUTF("ERROR: Comando non riconosciuto");
                    }
                }
            } catch (IOException e) {
                System.out.println("Errore nella gestione del client: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close(); // Chiude il socket del client
                } catch (IOException e) {
                    System.out.println("Errore nella chiusura del socket: " + e.getMessage());
                }
            }
        }

        // Metodo per caricare la lista dei file musicali nella directory "songs"
        private List<String> loadSongs() {
            File folder = new File(MUSIC_DIR);
            List<String> songs = new ArrayList<>();
            if (folder.exists() && folder.isDirectory()) {
                for (File file : Objects.requireNonNull(folder.listFiles())) {
                    if (file.isFile() && file.getName().endsWith(".mp3")) {
                        songs.add(file.getName()); // Aggiunge solo file con estensione ".mp3"
                    }
                }
            }
            return songs;
        }

        // Metodo per inviare un file al client
        private void sendFile(File file, DataOutputStream output) throws IOException {
            // Invia la dimensione del file al client
            long fileSize = file.length();
            output.writeLong(fileSize);
            output.flush();

            try (FileInputStream fileInputStream = new FileInputStream(file)) {
                byte[] buffer = new byte[4096]; // Buffer di 4KB
                int bytesRead;
                while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                    output.write(buffer, 0, bytesRead); // Invia i dati al client
                }
            }
            output.flush(); // Assicura che tutti i dati siano inviati
        }
    }
}
